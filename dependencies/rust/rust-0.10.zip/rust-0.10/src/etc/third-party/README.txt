Certain files in this distribution are covered by a different license than the rest of the Rust Project.
Specifically:

   - libgcc_s_dw2-1.dll and libstdc++6.dll are distributed under the terms of the GNU General Public License 
     with the GCC Runtime Library Exception as published by the Free Software Foundation; either version 3, 
     or (at your option) any later version.  See the files COPYING3 and COPYING.RUNTIME respectively.
     You can obtain a copy of the source of these libraries either here: http://sourceforge.net/projects/mingw/files/MinGW/Base/gcc/Version4/gcc-4.5.2-1/,
     or from the project website at http://gcc.gnu.org
