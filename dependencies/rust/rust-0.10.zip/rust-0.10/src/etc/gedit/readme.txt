Add syntax highlighting for Mozilla Rust in GtkSourceView (used by GEdit).


Instructions for Ubuntu Linux 12.04+

1) Close all instances of GEdit

2) Copy the included "share" folder into "~/.local/"

3) Open a shell in "~/.local/share/" and run "update-mime-database mime"
